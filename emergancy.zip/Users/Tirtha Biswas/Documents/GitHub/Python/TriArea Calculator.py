base = input('What is the base of the triangle in cetimetres? ')
height = input('What is the height of the triangle in cetimetres? ')
Calc = int(base) * int(height) * 0.5
print('The area is ' + str(Calc) + "cm.")