infinate = True
while infinate:
    input('Number: ')