birth_year = input('What year were you born in? ')
age = 2021 - int(birth_year)
print(f'You are {str(age)} years old')
