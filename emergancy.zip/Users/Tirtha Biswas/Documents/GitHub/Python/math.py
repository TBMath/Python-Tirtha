import math
cool = float('inf')
for nums in range(cool):
    print('a')