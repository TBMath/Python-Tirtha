def welcome(self):
    print('Greeting fellow Aliens')